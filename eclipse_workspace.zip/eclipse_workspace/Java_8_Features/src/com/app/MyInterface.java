package com.app;

public interface MyInterface {
	
	  void sayHello();

}
