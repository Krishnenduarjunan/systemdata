package com.app;

public class Lambda_Demo2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		MyInterface myInterface=()->{ System.out.println("Hai");};
		myInterface.sayHello();
	}

}
