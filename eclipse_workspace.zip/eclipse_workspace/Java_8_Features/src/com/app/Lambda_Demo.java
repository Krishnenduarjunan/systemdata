package com.app;

public class Lambda_Demo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		MyInterface myinterface=new MyInterface() {
			
			@Override
			public void sayHello() {
				System.out.println("java-8 features");
			}
		};
		myinterface.sayHello();

	}

}
