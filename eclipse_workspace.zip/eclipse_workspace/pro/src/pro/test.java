package pro;

import java.util.Arrays;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

public class test {
	public static void main(String[] args) {
		Integer[] numbers=new Integer[] {1,2,4,3,2,4,2};
		List numberList=Arrays.asList(numbers);
		
		//Set<Integer> newList=new LinkedHashSet<Integer>(numberList);
		
		//Set<Integer> newList=(Set<Integer>) numberList.stream().collect(Collectors.toSet());
		
		Set<Integer> newList=(Set<Integer>) numberList.stream().distinct().collect(Collectors.toList());
		
		//Set<Integer> newList=(Set<Integer>) numberList.stream().distinct().collect(Collectors.toSet());
		
		newList.forEach((i)->System.out.print(""+i));
	}
}
