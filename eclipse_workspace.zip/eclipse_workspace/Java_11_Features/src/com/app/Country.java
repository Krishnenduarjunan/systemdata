package com.app;

public class Country {
	String string;
	String string2;

	public Country(String string, String string2) {
		// TODO Auto-generated constructor stub
		this.string=string;
		this.string2=string2;
	}

}
