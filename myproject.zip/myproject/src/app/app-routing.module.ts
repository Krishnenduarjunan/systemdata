import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { DatabindingComponent } from './databinding/databinding.component';
import { DirectivesComponent } from './directives/directives.component';
import { ParentComponent } from './parent/parent.component';
import { AngularFormComponent } from './angular-form/angular-form.component';
import { PageNotFoundComponent } from './page-not-found/page-not-found.component';
import { UTDFComponent } from './utdf/utdf.component';
import { RTFComponent } from './rtf/rtf.component';
import { PipeComponent } from './pipe/pipe.component';
import { AngularMaterialComponent } from './angular-material/angular-material.component';

const routes: Routes = [
  { //default_routing and redirect routing
    path:"", 
    redirectTo:"databinding", 
    pathMatch:"full"
  },
  { //naming_routing
    path:"databinding",
    component: DatabindingComponent
  },
  { //parametarized_routing
    path:"directives/:id",
    component: DirectivesComponent
  },
  { //parametarized_routing
    path:"directives",
    component: DirectivesComponent
  },
  {
    path:"parent",
    component: ParentComponent
  },
  {
    path:"angMat",
    component: AngularMaterialComponent
  },
  {
    path:"pipe",
    component: PipeComponent
  },
  {
    path:"crud",
    loadChildren:()=> import('./crud/crud.module').then(m=>m.CrudModule)
  },
  {
    path:"angform",
    component: AngularFormComponent,
    children:[
      { path:"", component:UTDFComponent},
      { path:"utdf", component:UTDFComponent},
      { path:"rtf", component:RTFComponent}
    ]
  },
  { // wild-card routing
    path:"**",
    component: PageNotFoundComponent
  }
 
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
