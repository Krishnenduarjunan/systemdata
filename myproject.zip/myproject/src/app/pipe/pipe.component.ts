import { Component, OnInit } from '@angular/core';
import { DatePipe } from '@angular/common';

@Component({
  selector: 'app-pipe',
  templateUrl: './pipe.component.html',
  styleUrls: ['./pipe.component.css']
})
export class PipeComponent implements OnInit {

  d : Date = new Date();

  num:number=0;
  rad:number=0;
  msg:string="pipe is a function used to transform value";

  employee=[
    {id:101,name:"krishna",post:"Developer",salary:35500,gender:"female"},
    {id:102,name:"ciril",post:"Fullstack developer",salary:45500,gender:"male"},
    {id:103,name:"anitta",post:"Java Developer",salary:35500,gender:"female"},
    {id:104,name:"shijin",post:"tester",salary:35500,gender:"male"}
  ]

  constructor() { }

  ngOnInit(): void {
  }

}
