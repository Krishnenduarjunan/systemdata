import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-directives',
  templateUrl: './directives.component.html',
  styleUrls: ['./directives.component.css']
})
export class DirectivesComponent implements OnInit {

  isCond:boolean=false;
  colors:string[]=["Red","Blue","Green","Yellow"];
  mycolor:string="black";

  myStyle={
    color:"blue",
    fontSize:"30px",
    backgroundColor:"pink"
  }

  myClass={
    "txtDanger":this.isCond,
    "txtSuccess":!this.isCond,
    "special":!this.isCond
  }

  employee=[
    {id:101,name:"krishna",post:"Developer",salary:35500,gender:"female"},
    {id:102,name:"ciril",post:"Fullstack developer",salary:45500,gender:"male"},
    {id:103,name:"anitta",post:"Java Developer",salary:35500,gender:"female"},
    {id:104,name:"shijin",post:"tester",salary:35500,gender:"male"}
  ]


  constructor(private _router:Router) { }

  ngOnInit(): void {
  }

  setParameter(val:any){
    this._router.navigate(['/directives',val]);
  }

}
