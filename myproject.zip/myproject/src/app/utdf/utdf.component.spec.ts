import { ComponentFixture, TestBed } from '@angular/core/testing';

import { UTDFComponent } from './utdf.component';

describe('UTDFComponent', () => {
  let component: UTDFComponent;
  let fixture: ComponentFixture<UTDFComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ UTDFComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(UTDFComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
