import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { DatabindingComponent } from './databinding/databinding.component';
import { FormsModule } from '@angular/forms';
import { ImagetogglingComponent } from './imagetoggling/imagetoggling.component';
import { DirectivesComponent } from './directives/directives.component';
import { ParentComponent } from './parent/parent.component';
import { ChildComponent } from './child/child.component';
import { NavComponent } from './nav/nav.component';
import { FooterComponent } from './footer/footer.component';
import { AngularFormComponent } from './angular-form/angular-form.component';
import { UTDFComponent } from './utdf/utdf.component';
import { RTFComponent } from './rtf/rtf.component';
import { PageNotFoundComponent } from './page-not-found/page-not-found.component';
import { MygenderPipe } from './shared/custom/mygender.pipe';
import { PipeComponent } from './pipe/pipe.component';
import { CubePipe } from './shared/custom/cube.pipe';
import { AreaPipe } from './shared/custom/area.pipe';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { AngularMaterialComponent } from './angular-material/angular-material.component';
import { MaterialModule } from './material/material.module';


@NgModule({
  declarations: [
    AppComponent,
    DatabindingComponent,
    ImagetogglingComponent,
    DirectivesComponent,
    ParentComponent,
    ChildComponent,
    NavComponent,
    FooterComponent,
    AngularFormComponent,
    UTDFComponent,
    RTFComponent,
    PageNotFoundComponent,
    MygenderPipe,
    PipeComponent,
    CubePipe,
    AreaPipe,
    AngularMaterialComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    BrowserAnimationsModule,
    MaterialModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
