import { AreaPipe } from './area.pipe';

describe('AreaPipe', () => {
  it('create an instance', () => {
    const pipe = new AreaPipe();
    expect(pipe).toBeTruthy();
  });
});
