import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-databinding',
  templateUrl: './databinding.component.html',
  styleUrls: ['./databinding.component.css']
})
export class DatabindingComponent implements OnInit {

    myname:string= "krishnendu";
    imgPath:string= "../../assets/img1.jfif";
    imgName:string= "nature image";
    item: string= "";
  constructor() { }

  ngOnInit(): void {
  }

  greetings(){
    alert("Example for event binding");
  }

}
