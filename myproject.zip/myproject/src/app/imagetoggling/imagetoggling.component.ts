import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-imagetoggling',
  templateUrl: './imagetoggling.component.html',
  styleUrls: ['./imagetoggling.component.css']
})
export class ImagetogglingComponent implements OnInit {

  image:string="../../assets/img2.jfif";
  imgname:string="Mountain";

  constructor() { }

  ngOnInit(): void {
  }

  toggle(){
    if(this.image=="../../assets/img2.jfif"){
      this.image="../../assets/img1.jfif";
      this.imgname="Trees";
    }
    else{
      this.image="../../assets/img2.jfif";
      this.imgname="Mountain";
    }
    
  }

}
