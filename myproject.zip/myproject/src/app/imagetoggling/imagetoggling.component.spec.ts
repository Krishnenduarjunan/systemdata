import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ImagetogglingComponent } from './imagetoggling.component';

describe('ImagetogglingComponent', () => {
  let component: ImagetogglingComponent;
  let fixture: ComponentFixture<ImagetogglingComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ImagetogglingComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ImagetogglingComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
