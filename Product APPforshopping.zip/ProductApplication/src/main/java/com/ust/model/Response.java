package com.ust.model;

import java.util.List;

import com.ust.entity.Product;

public class Response {
	private String status;
	private List<Product> product;
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public List<Product> getProduct() {
		return product;
	}
	public void setProduct(List<Product> list) {
		this.product = list;
	}
	@Override
	public String toString() {
		return "Response [status=" + status + ", product=" + product + "]";
	}
}
